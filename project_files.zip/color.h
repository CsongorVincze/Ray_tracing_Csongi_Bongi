#ifndef COLOR_H
#define COLOR_H

#include "vec_3.h"
#include <stdio.h>

typedef vec_3 color;

int _color_divider(color v, FILE* fp);

#endif