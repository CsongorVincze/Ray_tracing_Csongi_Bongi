#ifndef COMMON_H
#define COMMON_H

void printCaption();

#endif
